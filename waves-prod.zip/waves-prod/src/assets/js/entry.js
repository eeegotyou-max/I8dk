import './index.js';
import './core/register.js';
import './core/load.js';
import './features/settings.js';
import './features/toast.js';
import './features/cloudsync.js';